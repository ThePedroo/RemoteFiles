MODPATH="${0%/*}"

rm -rf /data/adb/treat_wheel/status