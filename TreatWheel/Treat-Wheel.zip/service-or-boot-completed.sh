MODDIR="${0%/*}"

# INFO: Wait for all modules to execute to fix their shit

$MODDIR/cmd/treat-wheel &